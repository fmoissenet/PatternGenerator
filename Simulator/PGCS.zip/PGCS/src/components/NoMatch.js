import React, { Component } from 'react'
//import './App.css'

class NoMatch extends Component {
  render() {
    return (
      <div>
        Sorry, page not found
      </div>
    )
  }
}

export default NoMatch

